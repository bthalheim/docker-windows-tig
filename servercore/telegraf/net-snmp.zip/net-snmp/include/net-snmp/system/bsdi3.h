#include "bsdi.h"
#define bsdi2 bsdi2             /* bsdi3 is a superset of bsdi2 */
